# Changelog

## [1.3.19] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine/includes/admin/page-overview.php

## [1.3.18] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine/includes/admin/page-overview.php

## [1.3.17] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine.zip
- be-schema-engine/includes/admin/page-overview.php

## [1.3.16] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine.zip

## [1.3.15] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine/includes/admin/page-overview.php

## [1.3.14] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine/includes/admin/page-overview.php

## [1.3.13] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine/includes/admin/page-overview.php

## [1.3.12] - 2025-12-08
- Bump type: patch
- Files:
- be-schema-engine/includes/admin/page-overview.php

## [1.3.11] - 2025-12-08
- Bump type: patch
- Files:
- BE_SEO-Dev_Notes.json
- be-schema-engine/includes/admin/page-overview.php

## [1.3.10] - 2025-12-08
- Bump type: patch
- Files:
- .githooks/prepare-commit-msg

## [1.3.9] - 2025-12-08
- Bump type: patch
- Files:
- .githooks/pre-commit
- .githooks/prepare-commit-msg
- BE_SEO-Dev_Notes.json
- CHANGELOG.md
- be-schema-engine/be-schema-engine.php

## [1.3.8] - 2025-12-08
- Bump type: patch
- Files:
- .githooks/pre-commit
- .githooks/prepare-commit-msg
- BE_SEO-Dev_Notes.json
- CHANGELOG.md
- be-schema-engine/be-schema-engine.php

## [1.3.7] - 2025-12-08
- Bump type: patch
- Files:
- .githooks/pre-commit
- .githooks/prepare-commit-msg
- BE_SEO-Dev_Notes.json
- CHANGELOG.md
- be-schema-engine/be-schema-engine.php

## [1.3.6] - 2025-12-08
- Bump type: patch
- Files:
- .githooks/pre-commit
- .githooks/prepare-commit-msg
- BE_SEO-Dev_Notes.json
- CHANGELOG.md
- be-schema-engine/be-schema-engine.php

## [1.3.5] - 2025-12-08
- Bump type: patch
- Files:
- .githooks/pre-commit
- .githooks/prepare-commit-msg
- BE_SEO-Dev_Notes.json

## [1.3.4] - 2025-12-08
- Bump type: patch
- Files:
- .githooks/pre-commit
- BE_SEO-Dev_Notes.json
- CHANGELOG.md
- be-schema-engine/assets/images/admin/be_seo-landing_image.webp
- be-schema-engine/be-schema-engine.php
- be-schema-engine/includes/admin/admin-menu.php
- be-schema-engine/includes/admin/page-overview.php
- be-schema-engine/includes/engine/core-debug.php

## [1.3.0]
- Placeholder entry prior to pre-commit automation.
